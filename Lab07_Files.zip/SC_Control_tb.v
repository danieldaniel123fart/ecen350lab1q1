`timescale 1ns/1ps

module SC_Control_tb;

    // DUT ports
    reg  [10:0] opcode;
    wire        Reg2Loc, ALUSrc, MemtoReg, RegWrite;
    wire        MemRead, MemWrite, Branch, Uncondbranch;
    wire [3:0]  ALUOp;
    wire [1:0]  SignOp;

    SC_Control dut(
        .Reg2Loc(Reg2Loc),
        .ALUSrc(ALUSrc),
        .MemtoReg(MemtoReg),
        .RegWrite(RegWrite),
        .MemRead(MemRead),
        .MemWrite(MemWrite),
        .Branch(Branch),
        .Uncondbranch(Uncondbranch),
        .ALUOp(ALUOp),
        .SignOp(SignOp),
        .opcode(opcode)
    );

    // All outputs packed in one vector:
    // {Reg2Loc, ALUSrc, MemtoReg, RegWrite, MemRead, MemWrite, Branch, Uncondbranch, ALUOp, SignOp}
    wire [13:0] actual = {Reg2Loc, ALUSrc, MemtoReg, RegWrite, MemRead,
                          MemWrite, Branch, Uncondbranch, ALUOp, SignOp};

    // Opcode patterns (value) and opcode don't care masks (1 = don't care bit)
    localparam [10:0] P_LDUR = 11'b11111000010, M_LDUR = 11'b00000000000;
    localparam [10:0] P_STUR = 11'b11111000000, M_STUR = 11'b00000000000;
    localparam [10:0] P_ADD  = 11'b10001011000, M_ADD  = 11'b00000000000;
    localparam [10:0] P_SUBI = 11'b11010001000, M_SUBI = 11'b00000000001;
    localparam [10:0] P_AND  = 11'b10001010000, M_AND  = 11'b00000000000;
    localparam [10:0] P_ORR  = 11'b10101010000, M_ORR  = 11'b00000000000;
    localparam [10:0] P_CBZ  = 11'b10110100000, M_CBZ  = 11'b00000000111;
    localparam [10:0] P_B    = 11'b00010100000, M_B    = 11'b00000011111;

    integer errors;
    integer tests;
    integer seed;
    integer n;
    reg [10:0] rand_op;

    // Returns 1 if op matches any opcode the control unit supports
    function is_supported;
        input [10:0] op;
        begin
            is_supported = ((op & ~M_LDUR) == (P_LDUR & ~M_LDUR)) ||
                           ((op & ~M_STUR) == (P_STUR & ~M_STUR)) ||
                           ((op & ~M_ADD)  == (P_ADD  & ~M_ADD))  ||
                           ((op & ~M_SUBI) == (P_SUBI & ~M_SUBI)) ||
                           ((op & ~M_AND)  == (P_AND  & ~M_AND))  ||
                           ((op & ~M_ORR)  == (P_ORR  & ~M_ORR))  ||
                           ((op & ~M_CBZ)  == (P_CBZ  & ~M_CBZ))  ||
                           ((op & ~M_B)    == (P_B    & ~M_B));
        end
    endfunction

    // Apply one opcode and compare the outputs, ignoring don't care output bits
    task check;
        input [10:0]      op;
        input [13:0]      expected;
        input [13:0]      dc;        // 1 = don't care output bit
        input [8*10-1:0]  name;
        begin
            opcode = op;
            #10;
            tests = tests + 1;
            if ((actual & ~dc) !== (expected & ~dc))
            begin
                errors = errors + 1;
                $display("ERROR (%0s) opcode=%b: expected=%b dc=%b got=%b",
                         name, op, expected, dc, actual);
            end
        end
    endtask

    // Test every opcode value that matches the pattern over its don't care bits
    task test_instr;
        input [10:0]      pattern;
        input [10:0]      opdc;
        input [13:0]      expected;
        input [13:0]      dc;
        input [8*10-1:0]  name;
        integer i;
        reg [10:0] cand;
        begin
            for (i = 0; i < 2048; i = i + 1)
            begin
                cand = i;
                if ((cand & ~opdc) == (pattern & ~opdc))
                begin
                    check(cand, expected, dc, name);
                end
            end
        end
    endtask

    initial
    begin
        $dumpfile("SC_Control_tb.vcd");
        $dumpvars(0, SC_Control_tb);

        errors = 0;
        tests  = 0;
        seed   = 32'd12345;
        opcode = 11'b0;
        #10;

        //                                    Reg2Loc ALUSrc MemtoReg RegWrite MemRead MemWrite Branch Uncond ALUOp  SignOp
        //                                    expected value                      | don't care mask
        test_instr(P_LDUR, M_LDUR, 14'b0_1_1_1_1_0_0_0_0010_01, 14'b1_0_0_0_0_0_0_0_0000_00, "LDUR");
        test_instr(P_STUR, M_STUR, 14'b1_1_0_0_0_1_0_0_0010_01, 14'b0_0_1_0_0_0_0_0_0000_00, "STUR");
        test_instr(P_ADD,  M_ADD,  14'b0_0_0_1_0_0_0_0_0010_00, 14'b0_0_0_0_0_0_0_0_0000_11, "ADD");
        test_instr(P_SUBI, M_SUBI, 14'b0_1_0_1_0_0_0_0_0110_00, 14'b1_0_0_0_0_0_0_0_0000_00, "SUBI");
        test_instr(P_AND,  M_AND,  14'b0_0_0_1_0_0_0_0_0000_00, 14'b0_0_0_0_0_0_0_0_0000_11, "AND");
        test_instr(P_ORR,  M_ORR,  14'b0_0_0_1_0_0_0_0_0001_00, 14'b0_0_0_0_0_0_0_0_0000_11, "ORR");
        test_instr(P_CBZ,  M_CBZ,  14'b1_0_0_0_0_0_1_0_0111_10, 14'b0_0_1_0_0_0_0_0_0000_00, "CBZ");
        test_instr(P_B,    M_B,    14'b0_0_0_0_0_0_0_1_0000_11, 14'b1_1_1_0_0_0_0_0_1111_00, "B");

        // 10 random unsupported opcodes: every output must be exactly 0
        for (n = 0; n < 10; n = n + 1)
        begin
            rand_op = $random(seed);
            while (is_supported(rand_op))
            begin
                rand_op = $random(seed);
            end
            check(rand_op, 14'b0, 14'b0, "DEFAULT");
        end

        $display("Done: %0d tests run, %0d errors.", tests, errors);
        if (errors == 0)
        begin
            $display("ALL TESTS PASSED");
        end
        $finish;
    end

endmodule
