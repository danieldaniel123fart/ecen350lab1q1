module mux2to1_8 (
    input  wire [7:0] in0,   // two 8 bit inputs ()
    input  wire [7:0] in1,   
    input  wire       sel,  
    output reg  [7:0] out    // an 8 bit register to hold the values
);

    always @(*) begin // do on every clock cycle 
        if (sel == 1'b1)// if sel == 1 switch mux to in1 
            out = in1;
        else // base case sel==0 mux is on in0
            out = in0;
    end

endmodule