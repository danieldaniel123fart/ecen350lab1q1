`timescale 1ns/1ps

module tb_mux2to1_8;

    // Stimulus (reg) and observed output (wire)
    reg  [7:0] in0;
    reg  [7:0] in1;
    reg        sel;
    wire [7:0] out;

    // Testbench bookkeeping
    reg  [7:0] expected;
    integer    i;
    integer    errors;
    integer    tests;

    // Device under test
    mux2to1_8 dut (
        .in0(in0),
        .in1(in1),
        .sel(sel),
        .out(out)
    );

    // VCD dump
    initial begin
        $dumpfile("mux2to1_8.vcd");
        $dumpvars(0, tb_mux2to1_8);
    end

    // Exhaustive stimulus and checking
    initial begin
        errors = 0;
        tests  = 0;

        for (i = 0; i < 131072; i = i + 1) begin
            // Split the 17-bit counter into the three inputs
            {sel, in1, in0} = i[16:0];

            // Wait 5 ticks for the DUT to settle
            #5;

            // Reference model: what the output should be
            expected = (sel == 1'b1) ? in1 : in0;
            tests = tests + 1;

            // Check (!== also catches x/z) and print a message per stimulus
            if (out !== expected) begin
                errors = errors + 1;
                $display("[%0t] FAIL: sel=%b in1=%h in0=%h -> out=%h (expected %h)",
                         $time, sel, in1, in0, out, expected);
            end else begin
                $display("[%0t] PASS: sel=%b in1=%h in0=%h -> out=%h",
                         $time, sel, in1, in0, out);
            end
        end

        $display("--------------------------------------------");
        $display("Done: %0d vectors tested, %0d errors", tests, errors);
        if (errors == 0)
            $display("ALL TESTS PASSED");
        else
            $display("TESTS FAILED");
        $finish;
    end

endmodule