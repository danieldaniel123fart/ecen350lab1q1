module RegisterFile(
    output wire [63:0] BusA,
    output wire [63:0] BusB,
    input  wire [63:0] BusW,
    input  wire [4:0]  RA,
    input  wire [4:0]  RB,
    input  wire [4:0]  RW,
    input  wire        RegWr,
    input  wire        Clk
);

    // 32 registers x 64 bits (ARMv8: X0-X30 plus XZR as register 31)
    reg [63:0] regs [0:31];

    // Intermediate values for the combinational read logic
    reg [63:0] a_val;
    reg [63:0] b_val;

    // Write port: state element, so non-blocking assignment.
    // Writes to register 31 (XZR) are dropped.
    always @(posedge Clk) begin
        if (RegWr && (RW != 5'd31))
            regs[RW] <= BusW;
    end

    // Read ports: combinational, so blocking assignments.
    // Register 31 always reads as 0.
    always @(*) begin
        if (RA == 5'd31)
            a_val = 64'd0;
        else
            a_val = regs[RA];

        if (RB == 5'd31)
            b_val = 64'd0;
        else
            b_val = regs[RB];
    end

    // 3-tick delay on the outputs (simulation only; synthesis ignores it)
    assign #3 BusA = a_val;
    assign #3 BusB = b_val;

endmodule