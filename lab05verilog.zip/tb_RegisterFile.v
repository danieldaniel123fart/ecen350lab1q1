`timescale 1ns/1ps

module tb_RegisterFile;

    // DUT connections
    reg  [63:0] BusW;
    reg  [4:0]  RA, RB, RW;
    reg         RegWr;
    reg         Clk;
    wire [63:0] BusA, BusB;

    // Reference model: what each register should hold
    reg [63:0] shadow [0:31];

    reg [63:0] rand_val;
    reg [63:0] expected;
    integer    i;
    integer    errors;
    integer    tests;

    RegisterFile dut (
        .BusA(BusA), .BusB(BusB), .BusW(BusW),
        .RA(RA), .RB(RB), .RW(RW),
        .RegWr(RegWr), .Clk(Clk)
    );

    // Clock: 20 ns period
    initial Clk = 0;
    always #10 Clk = ~Clk;

    // VCD dump
    initial begin
        $dumpfile("RegisterFile.vcd");
        $dumpvars(0, tb_RegisterFile);
    end

    // One write attempt followed by a read-back check of the same register
    task write_and_check;
        input [4:0]  reg_num;
        input [63:0] data;
        input        we;
        begin
            // Change inputs away from the rising edge
            @(negedge Clk);
            RW    = reg_num;
            BusW  = data;
            RegWr = we;
            RA    = reg_num;
            RB    = reg_num;

            // Wait for the edge, then longer than the 3-tick output delay
            @(posedge Clk);
            #5;

            // Update the reference model the same way the hardware should behave
            if (we && reg_num != 5'd31)
                shadow[reg_num] = data;

            // Expected value: register 31 is always 0, else the model's stored value
            expected = (reg_num == 5'd31) ? 64'd0 : shadow[reg_num];
            tests = tests + 1;

            if (BusA !== expected || BusB !== expected) begin
                errors = errors + 1;
                $display("[%0t] FAIL: R%0d we=%b wrote=%h  BusA=%h BusB=%h expected=%h",
                         $time, reg_num, we, data, BusA, BusB, expected);
            end else begin
                $display("[%0t] PASS: R%0d we=%b wrote=%h  BusA=%h BusB=%h",
                         $time, reg_num, we, data, BusA, BusB);
            end
        end
    endtask

    initial begin
        errors = 0;
        tests  = 0;
        RegWr  = 0; RW = 0; RA = 0; RB = 0; BusW = 0;

        for (i = 0; i < 32; i = i + 1) begin
            // Write enable ON: random value should be stored (dropped for R31)
            rand_val = {$urandom, $urandom};
            write_and_check(i[4:0], rand_val, 1'b1);

            // Write enable OFF: a different random value must NOT be stored
            rand_val = {$urandom, $urandom};
            write_and_check(i[4:0], rand_val, 1'b0);
        end

        $display("--------------------------------------------");
        $display("Done: %0d checks, %0d errors", tests, errors);
        if (errors == 0) $display("ALL TESTS PASSED");
        else             $display("TESTS FAILED");
        $finish;
    end

endmodule